package com.lagou.mongodbcloud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MongodbCloudApplication {

    public static void main(String[] args) {
        SpringApplication.run(MongodbCloudApplication.class, args);
    }

}
