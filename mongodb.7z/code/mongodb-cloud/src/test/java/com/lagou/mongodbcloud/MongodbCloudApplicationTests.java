package com.lagou.mongodbcloud;

import com.lagou.mongodbcloud.entity.Resume;
import com.lagou.mongodbcloud.repository.ResumeRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@SpringBootTest
class MongodbCloudApplicationTests {
    @Autowired
    private ResumeRepository resumeRepository;

    @Test
    public void saveResume() throws ParseException {
        String  dateStr = "yyyy-MM-dd hh:mm:ss";
        SimpleDateFormat simpleDateFormat  = new SimpleDateFormat(dateStr);
        Date date = simpleDateFormat.parse("2000-10-01 08:00:00");
        for (int i = 0;i < 50; i++){
            Resume resume  = new Resume();
            resume.setName("test"+i);
            resume.setBirthday(date);
            resume.setExpectSalary(Math.random()*50000);
            if (i % 2 == 0){
                resume.setCity("北京");
            } else {
                resume.setCity("深圳");
            }
            resumeRepository.save(resume);
        }
    }

    @Test
    public void findAllResume(){
        List<Resume> resumeList = resumeRepository.findAll();
        for(Resume resume:resumeList){
            System.out.println("resume ===> "+resume.toString());
        }
    }
}
